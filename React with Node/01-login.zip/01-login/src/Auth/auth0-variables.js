export const AUTH_CONFIG = {
  domain: 'mrksihna2025.auth0.com',
  clientId: '6Vp3luZJH0Jdse55nJrZaIJ3lXbVali8',
  callbackUrl: 'http://localhost:3000/callback'
}
